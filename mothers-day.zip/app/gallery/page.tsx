"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { ChevronLeft, ChevronRight, Heart, ArrowLeft } from "lucide-react"

// Quotes data
const quotes = [
  {
    text: "A mother is she who can take the place of all others but whose place no one else can take.",
    author: "Cardinal Mermillod",
  },
  {
    text: "Mother's love is peace. It need not be acquired, it need not be deserved.",
    author: "Erich Fromm",
  },
  {
    text: "Life doesn't come with a manual, it comes with a mother.",
    author: "Unknown",
  },
  {
    text: "A mother's arms are made of tenderness and children sleep soundly in them.",
    author: "Victor Hugo",
  },
  {
    text: "To the world you are a mother, but to your family you are the world.",
    author: "Unknown",
  },
]

export default function GalleryPage() {
  const [currentQuote, setCurrentQuote] = useState(0)
  const [isLoaded, setIsLoaded] = useState(false)

  // Auto-rotate quotes
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentQuote((prev) => (prev + 1) % quotes.length)
    }, 5000)

    setIsLoaded(true)

    return () => clearInterval(interval)
  }, [])

  const nextQuote = () => {
    setCurrentQuote((prev) => (prev + 1) % quotes.length)
  }

  const prevQuote = () => {
    setCurrentQuote((prev) => (prev - 1 + quotes.length) % quotes.length)
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-yellow-50 to-pink-50 py-8">
      {/* Navigation */}
      <nav className="p-4 flex justify-center gap-6 text-pink-700 font-medium">
        <Link href="/" className="relative group">
          <span>Home</span>
          <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-pink-300 transform scale-x-0 group-hover:scale-x-100 transition-transform"></span>
        </Link>
        <Link href="/letter" className="relative group">
          <span>Letter</span>
          <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-pink-300 transform scale-x-0 group-hover:scale-x-100 transition-transform"></span>
        </Link>
        <Link href="/gallery" className="relative group">
          <span>Gallery</span>
          <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-pink-300 transform scale-x-100 transition-transform"></span>
        </Link>
      </nav>

      {/* Quote Slider */}
      <section className="max-w-4xl mx-auto px-4 py-8">
        <div className="relative bg-white bg-opacity-80 p-6 md:p-8 rounded-lg shadow-lg border border-pink-100 mb-12">
          <div className="flex items-center">
            <button
              onClick={prevQuote}
              className="p-2 text-pink-600 hover:text-pink-800 transition-colors"
              aria-label="Previous quote"
            >
              <ChevronLeft className="h-6 w-6" />
            </button>

            <div className="flex-1 min-h-[120px] flex items-center justify-center">
              <div className={`text-center transition-opacity duration-500 ${isLoaded ? "opacity-100" : "opacity-0"}`}>
                <blockquote className="text-lg md:text-xl text-purple-800 italic font-serif leading-relaxed mb-2">
                  "{quotes[currentQuote].text}"
                </blockquote>
                <footer className="text-pink-600">— {quotes[currentQuote].author}</footer>
              </div>
            </div>

            <button
              onClick={nextQuote}
              className="p-2 text-pink-600 hover:text-pink-800 transition-colors"
              aria-label="Next quote"
            >
              <ChevronRight className="h-6 w-6" />
            </button>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="max-w-6xl mx-auto px-4 py-8">
        <h2 className="text-3xl font-serif text-pink-700 mb-8 text-center">Our Beautiful Memories</h2>

        {/* Honeycomb Gallery */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className={`group relative overflow-hidden rounded-lg shadow-lg transition-transform duration-300 hover:scale-105 ${
                i % 3 === 0 ? "md:translate-y-8" : i % 3 === 1 ? "md:translate-y-0" : "md:translate-y-4"
              }`}
              style={{
                aspectRatio: i % 2 === 0 ? "1/1" : "4/5",
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-t from-pink-900/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                <div className="p-4 text-white">
                  <Heart className="h-5 w-5 text-pink-300 mb-1" />
                  <p className="text-sm font-light">Beautiful memory {i + 1}</p>
                </div>
              </div>
              <Image
                src={`/placeholder.svg?height=${300 + i * 20}&width=${300 + i * 20}`}
                alt={`Memory ${i + 1}`}
                fill
                className="object-cover transition-transform duration-500 group-hover:scale-110"
                sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
              />
            </div>
          ))}
        </div>

        {/* Polaroid Gallery */}
        <div className="mt-16 mb-8">
          <h3 className="text-2xl font-serif text-pink-700 mb-8 text-center">Special Moments</h3>
          <div className="flex flex-wrap justify-center gap-6">
            {[...Array(4)].map((_, i) => (
              <div
                key={i}
                className="w-64 bg-white p-3 shadow-lg transform transition-transform duration-300 hover:rotate-3 hover:-translate-y-2"
                style={{
                  transform: `rotate(${(i % 2 === 0 ? 2 : -2) * (i + 1)}deg)`,
                }}
              >
                <div className="relative h-56 mb-3 overflow-hidden">
                  <Image
                    src={`/placeholder.svg?height=224&width=240`}
                    alt={`Special moment ${i + 1}`}
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 100vw, 240px"
                  />
                </div>
                <p className="text-center text-gray-700 font-light text-sm">A special moment with mom ❤️</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Back to Home */}
      <div className="text-center mt-8 mb-12">
        <Link
          href="/"
          className="inline-flex items-center gap-2 px-6 py-2 bg-pink-100 text-pink-700 rounded-full border border-pink-200 hover:bg-pink-200 transition-colors shadow-md"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Home</span>
        </Link>
      </div>

      {/* Footer */}
      <footer className="py-6 text-center text-pink-600 text-sm">
        <p>Made with ❤️ for the best mom in the world</p>
      </footer>
    </main>
  )
}
