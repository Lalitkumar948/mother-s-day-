import Link from "next/link"
import Image from "next/image"

export default function LetterPage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-lavender-50 to-pink-50 py-8">
      {/* Navigation */}
      <nav className="p-4 flex justify-center gap-6 text-pink-700 font-medium">
        <Link href="/" className="relative group">
          <span>Home</span>
          <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-pink-300 transform scale-x-0 group-hover:scale-x-100 transition-transform"></span>
        </Link>
        <Link href="/letter" className="relative group">
          <span>Letter</span>
          <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-pink-300 transform scale-x-100 transition-transform"></span>
        </Link>
        <Link href="/gallery" className="relative group">
          <span>Gallery</span>
          <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-pink-300 transform scale-x-0 group-hover:scale-x-100 transition-transform"></span>
        </Link>
      </nav>

      {/* Letter Section */}
      <section className="max-w-3xl mx-auto px-4 py-12">
        <div className="relative bg-white bg-opacity-90 p-8 md:p-12 rounded-lg shadow-lg border border-pink-100">
          {/* Decorative elements */}
          <div className="absolute -top-6 -left-6 w-20 h-20 opacity-30">
            <Image
              src="/placeholder.svg?height=80&width=80"
              alt="Floral decoration"
              width={80}
              height={80}
              className="object-contain"
            />
          </div>
          <div className="absolute -bottom-6 -right-6 w-20 h-20 opacity-30">
            <Image
              src="/placeholder.svg?height=80&width=80"
              alt="Floral decoration"
              width={80}
              height={80}
              className="object-contain"
            />
          </div>

          {/* Letter content */}
          <div className="relative z-10">
            <h1 className="text-3xl md:text-4xl font-serif text-pink-700 mb-8 text-center">Dear Mom,</h1>
            <div className="space-y-4 text-purple-800 leading-relaxed font-light">
              <p>
                On this special day, I wanted to take a moment to express just how much you mean to me. Words can never
                fully capture the depth of my gratitude for everything you've done and continue to do.
              </p>
              <p>
                You've been my first teacher, my constant supporter, and my greatest inspiration. Through every
                challenge and triumph, your unwavering love has been my foundation.
              </p>
              <p>
                I cherish all our memories together—the laughter we've shared, the lessons you've taught me, and even
                the difficult moments that have made us stronger. Your wisdom guides me daily, and your strength
                inspires me to be the best version of myself.
              </p>
              <p>
                Thank you for your patience when I tested it, your guidance when I felt lost, and your unconditional
                love through it all. You've shaped me into who I am today, and for that, I am eternally grateful.
              </p>
              <p className="pt-4">With all my love and appreciation,</p>
              <p className="font-serif text-xl text-pink-700">Your loving child</p>
            </div>
          </div>
        </div>

        <div className="mt-8 text-center">
          <Link
            href="/gallery"
            className="inline-flex items-center gap-2 px-6 py-2 bg-pink-100 text-pink-700 rounded-full border border-pink-200 hover:bg-pink-200 transition-colors shadow-md"
          >
            <span>View Our Memories</span>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-6 text-center text-pink-600 text-sm">
        <p>Made with ❤️ for the best mom in the world</p>
      </footer>
    </main>
  )
}
