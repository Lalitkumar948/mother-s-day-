import Link from "next/link"
import Image from "next/image"
import { Heart } from "lucide-react"

export default function HomePage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-pink-50 to-purple-50">
      {/* Navigation */}
      <nav className="p-4 flex justify-center gap-6 text-pink-700 font-medium">
        <Link href="/" className="relative group">
          <span>Home</span>
          <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-pink-300 transform scale-x-0 group-hover:scale-x-100 transition-transform"></span>
        </Link>
        <Link href="/letter" className="relative group">
          <span>Letter</span>
          <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-pink-300 transform scale-x-0 group-hover:scale-x-100 transition-transform"></span>
        </Link>
        <Link href="/gallery" className="relative group">
          <span>Gallery</span>
          <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-pink-300 transform scale-x-0 group-hover:scale-x-100 transition-transform"></span>
        </Link>
      </nav>

      {/* Hero Section */}
      <section className="relative px-4 py-20 flex flex-col items-center justify-center text-center">
        {/* Decorative elements */}
        <div className="absolute top-0 left-0 w-40 h-40 opacity-20">
          <Image
            src="/placeholder.svg?height=150&width=150"
            alt="Floral decoration"
            width={150}
            height={150}
            className="object-contain"
          />
        </div>
        <div className="absolute bottom-0 right-0 w-40 h-40 opacity-20">
          <Image
            src="/placeholder.svg?height=150&width=150"
            alt="Floral decoration"
            width={150}
            height={150}
            className="object-contain"
          />
        </div>

        {/* Main content */}
        <div className="relative z-10 max-w-3xl mx-auto">
          <div className="mb-6 flex justify-center">
            <Heart className="text-pink-400 h-16 w-16 animate-pulse" />
          </div>
          <h1 className="text-4xl md:text-6xl font-serif text-pink-700 mb-6">Happy Mother&apos;s Day</h1>
          <p className="text-xl md:text-2xl text-purple-700 font-light mb-8 leading-relaxed">
            To the woman who gave me life, taught me love, and shows me strength every day.
          </p>
          <div className="relative inline-block">
            <Link
              href="/letter"
              className="relative z-10 px-8 py-3 bg-pink-100 text-pink-700 rounded-full border border-pink-200 hover:bg-pink-200 transition-colors shadow-md"
            >
              Read My Letter
            </Link>
            <div className="absolute -bottom-2 -right-2 w-full h-full bg-pink-300 rounded-full opacity-30"></div>
          </div>
        </div>
      </section>

      {/* Quote Section */}
      <section className="py-16 px-4">
        <div className="max-w-2xl mx-auto bg-white bg-opacity-70 p-8 rounded-lg shadow-lg border border-pink-100">
          <blockquote className="text-center">
            <p className="text-lg md:text-xl text-purple-800 italic font-serif leading-relaxed mb-4">
              "A mother's arms are more comforting than anyone else's."
            </p>
            <footer className="text-pink-600">— Princess Diana</footer>
          </blockquote>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-6 text-center text-pink-600 text-sm">
        <p>Made with ❤️ for the best mom in the world</p>
      </footer>
    </main>
  )
}
